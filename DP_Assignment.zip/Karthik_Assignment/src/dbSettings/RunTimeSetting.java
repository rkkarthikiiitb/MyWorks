package dbSettings;

public class RunTimeSetting {
	
	 public static String dbUser="root"; 
	 public static String dbPwd="adithri";
	 public static String dbName="dp_assignment";
	 public static String url="jdbc:mysql://localhost/";
	 
	 
}
