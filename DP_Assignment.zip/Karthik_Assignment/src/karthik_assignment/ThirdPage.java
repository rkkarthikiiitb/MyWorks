package karthik_assignment;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;

import dbSettings.MySqlConnection;


public class ThirdPage extends WizardPage {
	
	  DateTime mycalendar;
	  private Composite mycontainer;
	  boolean myflag;
	  String travelAgentName;
	  public String getTravelAgentName() {
		return travelAgentName;
	}



	public String getDate() {
		return date;
	}


	String date;
	  Vector<String> agentsName = new Vector<String>();
	  ListViewer listviewer;

	  public ThirdPage() {
	    super("Third Page");
	    setTitle("Select Agent - Choose Date");
	    setDescription("Pick your agent");
	  }

	  @Override
	  public void createControl(Composite parent) {
	    mycontainer = new Composite(parent, SWT.NULL);
	    GridLayout layout = new GridLayout();
	    mycontainer.setLayout(layout);
	    layout.numColumns = 2;
	    Label agent = new Label(mycontainer, SWT.NULL);
	    agent.setText("Pick an agent");
	    
	    queueAgent();
	    
	    listviewer = new ListViewer(mycontainer,SWT.SINGLE);
	    
	    listviewer.setContentProvider(new ArrayContentProvider());  
	    
	  listviewer.setInput(agentsName);

	 
	  

	  listviewer.addSelectionChangedListener(new ISelectionChangedListener() {
		         public void selectionChanged(SelectionChangedEvent event) {

		        	     myflag=true;
		               
		        	 
		        	 IStructuredSelection selection =(IStructuredSelection) event.getSelection();
		            System.out.println("Selected: "
		               + selection.getFirstElement());
		            travelAgentName=selection.getFirstElement()+"";
		         }
		      });
		      
	  Label dateSelection = new Label(mycontainer, SWT.NULL);
	  dateSelection.setText("Select a Date of your Trip");
	    mycalendar = new DateTime(mycontainer, SWT.CALENDAR);
	    
	    mycalendar.addSelectionListener (new SelectionAdapter () {
	        public void widgetSelected (SelectionEvent e) {
	        System.out.println(mycalendar.getYear());
	         
	          if (mycalendar.getEnabled()&& myflag) {
	              setPageComplete(true);

	            }
	          date=mycalendar.getDay()+"-"+mycalendar.getMonth()+"-"+mycalendar.getYear();
	                            
	        }
	    }); 
	    GridData gd = new GridData(GridData.FILL_HORIZONTAL);
	   
	    listviewer.getControl().setLayoutData(gd);
	    
	    setControl(mycontainer);
	    setPageComplete(false);

	  }

	private void queueAgent() {
		
		Connection con=MySqlConnection.getConnection();
	    	Statement s1=null;
	    	ResultSet r1=null;
	    	
	    	String myquery="Select * from myagents";
	    try {
	    	s1=con.createStatement();
			r1=s1.executeQuery(myquery);
			while(r1.next()){
				agentsName.add(r1.getString("Agent_Name"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
