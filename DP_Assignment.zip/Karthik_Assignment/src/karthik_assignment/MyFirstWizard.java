package karthik_assignment;


import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import karthik_assignment.FirstPage;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.ui.IWorkbench;

import dbSettings.MySqlConnection;


//import com.mysql.jdbc.Connection;
//import com.mysql.jdbc.Statement;

public class MyFirstWizard extends Wizard {
	
	// Wizard pages
	private WizardPage myFirstPage = null;
	private WizardPage mySecondPage = null;
	private WizardPage myThirdPage = null;
	
	/**
	 * Constructor
	 */
	
	
	public MyFirstWizard() {
		super();
		setNeedsProgressMonitor(true);
		
		 myFirstPage =new FirstPage();
		 mySecondPage = new SecondPage();
		 myThirdPage = new ThirdPage();
				
		setWindowTitle("Travel Wizard");
	}
	
	@Override
	public void addPages() {
		
		// Add pages
		addPage(myFirstPage);
		addPage(mySecondPage);
		addPage(myThirdPage);
	}
	
	@Override
	public boolean performFinish() {
		
		
		
		Connection con=MySqlConnection.getConnection();
	    Statement st=null;
    	int rs=0;
    	
    	String query="Insert into tourstable(Tour_Name,Loc_From,Loc_To,Loc_Via,Agent_Name,Journey_Date) values('"+((FirstPage)myFirstPage).getText_mytourname()+"','"+((SecondPage)mySecondPage).getText_from()+"','"+((SecondPage)mySecondPage).getText_to()+"','"+((SecondPage)mySecondPage).getText_via()+"','"+((ThirdPage)myThirdPage).getTravelAgentName()+"','"+((ThirdPage)myThirdPage).getDate()+"')";
    try {
    	st=con.createStatement();
		rs=st.executeUpdate(query);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 
    	return true;
		
	//	return true;
		
	}

	public void init(IWorkbench workbench, IStructuredSelection selection) {
		// TODO Auto-generated method stub
		
	}
}
