package karthik_assignment;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class FirstPage extends WizardPage {
	
	private Composite myparent = null;
	private Label label_mytourname = null;
	private Text text_mytourname;
	
	
		public String getText_mytourname() {
		return text_mytourname.getText();
	}

	public void setText_mytourname(Text text_mytourname) {
		this.text_mytourname = text_mytourname;
	}


	public FirstPage() {
		super("Create File - Name Info");
		setTitle("Create File - Name Info");
		setDescription("First page of the Wizard");
	}

	@Override
	public void createControl(Composite parent) {
		
		// Create parent container
		myparent = new Composite(parent, SWT.NONE);
		
		// Set layout to parent
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		myparent.setLayout(gridLayout);
		
		// Add widget
		label_mytourname = new Label(myparent, SWT.NONE);
		label_mytourname.setText("Name your Tour:");
		
		// Add widget
		text_mytourname = new Text(myparent, SWT.BORDER);
		text_mytourname.setToolTipText("Name your Tour");
		text_mytourname.addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
				
				if ( (text_mytourname.getText().isEmpty() == false))
					setPageComplete(true);
				else
					setPageComplete(false);
			}
			
		});
		text_mytourname.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
		
		
		setControl(myparent);
		
	
		setPageComplete(false);
	}

	
}
