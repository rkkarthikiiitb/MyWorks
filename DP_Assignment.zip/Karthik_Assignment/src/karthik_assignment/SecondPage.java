package karthik_assignment;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

public class SecondPage extends WizardPage implements KeyListener {

	private Composite myparent = null;
	private Label label_from = null;
	private Label label_to = null;
	private Label label_via = null;
	private Text text_from=null;
	private Text text_to = null;
	private Text text_via = null;
	
	

	
		
	public String getText_from() {
		return text_from.getText();
	}

	public void setText_from(Text text_from) {
		this.text_from = text_from;
	}

	public String getText_to() {
		return text_to.getText();
	}

	public void setText_to(Text text_to) {
		this.text_to = text_to;
	}

	public String getText_via() {
		return text_via.getText();
	}

	public void setText_via(Text text_via) {
		this.text_via = text_via;
	}

	/**
	 * Constructor
	 */
	public SecondPage() {
		super("Create File - Address Info");
		setTitle("Create File - Address Info");
		setDescription("Second page of the Wizard");
	}

	@Override
	public void createControl(Composite parent) {
		
		// Create parent
		myparent = new Composite(parent, SWT.NONE);
		
		// Set layout to parent
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		myparent.setLayout(gridLayout);
		
		// Add widget
		label_from = new Label(myparent, SWT.NONE);
		label_from.setText("From");
		
		// Add widget
		text_from = new Text(myparent, SWT.BORDER);
		text_from.setToolTipText("From");
		text_from.addKeyListener(this);
		text_from.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
		
		// Add widget
		label_to = new Label(myparent, SWT.NONE);
		label_to.setText("To");
		
		// Add widget
		text_to = new Text(myparent, SWT.BORDER);
		text_to.setToolTipText("To");
		text_to.addKeyListener(this);
		text_to.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
		
		// Add widget
		label_via = new Label(myparent, SWT.NONE);
		label_via.setText("via");
		
		// Add widget
		text_via = new Text(myparent, SWT.BORDER);
		text_via.setToolTipText("via");
		text_via.addKeyListener(this);
		text_via.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_HORIZONTAL));
	
		setControl(myparent);
		
		// Set page status
		setPageComplete(false);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
		if (text_from.getText().isEmpty() == false &&
				text_to.getText().isEmpty() == false &&
				text_via.getText().isEmpty() == false) {
			setPageComplete(true);
		} else {
			setPageComplete(false);
		}
		
	}

}
