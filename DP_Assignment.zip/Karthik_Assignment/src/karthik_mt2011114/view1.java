package karthik_mt2011114;

import karthik_assignment.MyFirstWizard;

import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.ui.part.ViewPart;

public class view1 extends ViewPart {

	public view1() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createPartControl(Composite parent) {
		
	parent.setLayout(new GridLayout());	
	Button bt =new Button(parent,SWT.NONE);
	bt.setText("Run Karthik's Wizard");
    bt.addSelectionListener(new SelectionAdapter() {
	public void widgetSelected(SelectionEvent e)
	{
		WizardDialog dialog = new WizardDialog(getViewSite().getShell(), new MyFirstWizard());
        dialog.open();
		
	}
    })	;

	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

}
